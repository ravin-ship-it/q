# ANSI Colors (Using ANSI-C quoting for real escape characters)
C_RESET=$'\e[0m'
C_GRAY=$'\e[0;90m'
C_CYAN=$'\e[1;36m'
C_GREEN=$'\e[1;32m'
C_YELLOW=$'\e[1;33m'
C_ORANGE=$'\e[38;5;215m' # Light Orange
C_PINK=$'\e[38;5;198m'
C_LIGHT_PINK=$'\e[38;5;211m'
C_PURPLE=$'\e[1;38;5;171m' # Vibrant Purple
C_VIOLET=$'\e[38;5;129m'   # Violet
C_TEAL=$'\e[1;38;5;37m'    # Teal
C_WHITE=$'\e[1;37m'
C_BOLD=$'\e[1m'

# Get Terminal Width
TERM_WIDTH=$(tput cols)
[ -z "$TERM_WIDTH" ] && TERM_WIDTH=80
[ "$TERM_WIDTH" -lt 40 ] && TERM_WIDTH=40
BOX_WIDTH=$((TERM_WIDTH - 2))
INNER_WIDTH=$((BOX_WIDTH - 4)) 

# Create Horizontal Lines
printf -v H_LINE "%*s" "$((TERM_WIDTH))" ""
H_LINE=${H_LINE// /─}

strip_colors() {
    # Strip real ESC (x1B) sequences
    echo "$1" | sed "s/$(echo -e '\033')\[[0-9;]*[a-zA-Z]//g"
}

get_visual_width() {
    echo -n "$1" | wc -L
}

print_header_box() {
    local title="$1"
    local width=$TERM_WIDTH
    [ -z "$width" ] && width=80
    
    printf -v T_LINE "╭%*s╮" "$((width - 2))" ""
    T_LINE=${T_LINE// /─}
    printf -v M_LINE "├%*s┤" "$((width - 2))" ""
    M_LINE=${M_LINE// /─}
    
    echo -e "${C_PURPLE}${T_LINE}${C_RESET}"
    local visible_text=$(strip_colors "$title")
    local visible_width=$(get_visual_width "$visible_text")
    local pad_len=$((width - visible_width - 4))
    [ $pad_len -lt 0 ] && pad_len=0
    printf -v PADDING "%*s" "$pad_len" ""
    echo -e "${C_PURPLE}│${C_RESET} ${title}${PADDING} ${C_PURPLE}│${C_RESET}"
    echo -e "${C_PURPLE}${M_LINE}${C_RESET}"
}

print_boxed_line() {
    local content="$1"
    local borderless="${2:-false}"
    
    if [ "$borderless" == "true" ]; then
        printf " %b\n" "$content"
    else
        local visible_content=$(strip_colors "$content")
        local visible_width=$(get_visual_width "$visible_content")
        local pad_len=$((TERM_WIDTH - visible_width - 4))
        [ $pad_len -lt 0 ] && pad_len=0
        printf -v PADDING "%*s" "$pad_len" ""
        printf "${C_PURPLE}│${C_RESET} %b%s ${C_PURPLE}│${C_RESET}\n" "$content" "$PADDING"
    fi
}

truncate_text() {
    local text="$1"
    local max_len="$2"
    local width=$(get_visual_width "$text")
    if [ "$width" -gt "$max_len" ]; then
        local truncated="$text"
        while [ $(get_visual_width "${truncated}...") -gt "$max_len" ] && [ ${#truncated} -gt 0 ]; do
            truncated="${truncated:0:-1}"
        done
        echo "${truncated}..."
    else
        echo "$text"
    fi
}

get_input() {
    local header="$1"
    local prompt="${2:-Name > }"
    local tmp=$(mktemp)
    # Use fzf as a polished input box. 
    # IMPORTANT: We redirect stdin from /dev/tty for the interactive part 
    # while providing /dev/null for the item list.
    fzf --header "  $header" --prompt "  $prompt" \
        --height=5 --layout=reverse --border --info=hidden \
        --color="fg:#00ffff,hl:#ff1493,fg+:#ff1493,hl+:#ff1493,pointer:#ff1493,marker:#ff1493,border:#5f5f5f" \
        --bind 'ctrl-v:transform-query(echo -n {q}; termux-clipboard-get)' \
        --print-query < /dev/null > "$tmp" < /dev/tty
    
    local exit_code=$?
    # fzf returns 1 if no match is selected (always true here), 
    # but 130 if cancelled (ESC). 0 or 1 means query captured.
    if [ "$exit_code" -eq 0 ] || [ "$exit_code" -eq 1 ]; then
        head -n1 "$tmp"
    else
        echo ""
    fi
    rm -f "$tmp"
    # Small breather for terminal restoration
    sleep 0.1
}

show_help() {
    print_header_box "${C_CYAN}🎵 MPV Queue Manager Help${C_RESET}"
    print_boxed_line "${C_BOLD}Usage:${C_RESET}"
    print_boxed_line "  q               Interactive Queue (fzf)"
    print_boxed_line "  q <url>         Add URL/File to queue"
    print_boxed_line "  q <query>       Search and select to queue"
    print_boxed_line ""
    print_boxed_line "${C_YELLOW}Commands:${C_RESET}"
    print_boxed_line "  -i [N|url]      Metadata & Download Info (Synced Resolution)"
    print_boxed_line "  -p [N]          Play/Pause or Jump to track N ${C_GRAY}(Supports: 10+5)${C_RESET}"
    print_boxed_line "  -next / -prev   Next/Prev track ${C_GRAY}(Synced Logs)${C_RESET}"
    print_boxed_line "  -stop           Stop (Quit) MPV"
    print_boxed_line "  -v [N]          Volume Control (Show or Set to N)"
    print_boxed_line "  -fx [mode]      Audio FX: on | off | toggle | status"
    print_boxed_line "  -mv <A> <B>     Move track A to B"
    print_boxed_line "  -sw <A> <B>     Swap track A and B"
    print_boxed_line "  -rname <O> <N>  Rename playlist or local file"
    print_boxed_line "  -rm [N|txt]     Remove track ${C_GRAY}(Defaults to Current)${C_RESET}"
    print_boxed_line "  -rmr            Remove redundant tracks (dupes)"
    print_boxed_line "  -clean          Remove Private/Deleted videos"
    print_boxed_line "  -l / -lp        Toggle Loop (Track / Playlist)"
    print_boxed_line "  -shuf [list]    Shuffle Mode or actual Queue Entries"
    print_boxed_line "  -clr            Clear entire queue"
    print_boxed_line "  -auto           Toggle Auto-Discovery (24/7 Related Hits)"
    print_boxed_line "  -raw            Raw Queue output (for scripts)"
    print_boxed_line ""
    print_boxed_line "${C_YELLOW}Custom Playlists:${C_RESET}"
    print_boxed_line "  -pl-save <N>    Save current queue as <N>"
    print_boxed_line "  -pl-load [N]    Load playlist(s) ${C_GRAY}(FZF Menu if empty)${C_RESET}"
    print_boxed_line "  -pl-list        List saved playlists (Interactive Explorer)"
    print_boxed_line "  -pl-raw [N]     List playlists or contents (Raw)"
    print_boxed_line "  -pl-rm <N>      Delete playlist <N>"
    print_boxed_line "  -pl-clean <N>   Remove dead tracks from playlist <N>"
    print_boxed_line "  -pl-rmr <N>     Remove duplicates from playlist <N>"
    print_boxed_line "  -to <N>         Dir. search results to playlist <N>"
    print_boxed_line ""
    print_boxed_line "${C_YELLOW}Interactive (FZF) Controls:${C_RESET}"
    print_boxed_line "  TAB             Select / Mark track ${C_GRAY}(Triggers Action Menu)${C_RESET}"
    print_boxed_line "  ALT-A           Toggle Selection (Invert All)"
    print_boxed_line "  INSERT          Select All"
    print_boxed_line "  DELETE          Deselect All"
    print_boxed_line "  ENTER           Direct Play ${C_GRAY}(or Action Menu if tracks selected)${C_RESET}"
    print_boxed_line ""
    print_boxed_line "${C_YELLOW}Searching:${C_RESET}"
    print_boxed_line "  q yt <q>        Force YouTube search"
    print_boxed_line "  q sc <q>        Force Soundcloud search"
    printf -v B_LINE "╰%*s╯" "$((TERM_WIDTH - 2))" ""
    B_LINE=${B_LINE// /─}
    echo -e "${C_GRAY}${B_LINE}${C_RESET}"
}
